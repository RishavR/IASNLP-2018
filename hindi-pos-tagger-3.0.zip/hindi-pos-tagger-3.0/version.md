# Hindi POS tagger versions

## version 3.0
* Changes to Tokenizer
* A new normalizer to spellings
* Git repository
